This program was developed for the purpose of optimizing WINDOWS devices.
 It does not have any malicious system. Distribution by third parties is not recommended! 
Any version of my program (OPTIMIZER) that is not made directly by me (Fabio Lucas L.) 
should not be downloaded as it contains a risk of fraud.

The program automatically cleans areas that are not
harmful to touch windows.

thanks.